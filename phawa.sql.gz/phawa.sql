-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2021 at 04:33 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phawa`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointmenttbl`
--

CREATE TABLE `appointmenttbl` (
  `aptid` int(100) NOT NULL,
  `doctorid` int(100) NOT NULL,
  `patientid` int(100) NOT NULL,
  `apdtname` varchar(100) NOT NULL,
  `apptname` varchar(100) NOT NULL,
  `appdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointmenttbl`
--

INSERT INTO `appointmenttbl` (`aptid`, `doctorid`, `patientid`, `apdtname`, `apptname`, `appdate`) VALUES
(16, 16, 36, 'Prof. Dr. Tamzeed Ahmed ', 'MD.JAWADUL HASAN', '2021-10-16'),
(19, 40, 36, 'Dr. Abdullah-Al-Safia ', 'MD.JAWADUL HASAN', '2021-10-27'),
(20, 16, 36, 'Prof. Dr. Tamzeed Ahmed ', 'MD.JAWADUL HASAN', '2021-10-07'),
(22, 9, 33, 'MD.JAWADUL HASAN', 'jh', '2021-09-29'),
(23, 25, 33, 'Dr. Indrajit Prasad ', 'jh', '2021-10-28'),
(24, 30, 33, 'Dr. Md. Anisur Rahman ', 'jh', '2021-10-18'),
(25, 26, 33, 'Dr. Afsana Begum', 'jh', '2021-10-11'),
(26, 21, 37, 'Dr. Zafar A. Latif ', 'joy vaiu', '2021-09-29'),
(27, 9, 37, 'MD.JAWADUL HASAN', 'joy vaiu', '2029-05-05'),
(28, 55, 37, 'Dr. Kamal Sayed Ahmed  Chowdhury', 'joy vaiu', '2021-10-19'),
(29, 59, 37, 'Ishan Islam', 'joy vaiu', '2021-10-06'),
(30, 13, 36, 'Dr. Tahera Nazrin ', 'MD.JAWADUL HASAN', '2021-10-21'),
(31, 13, 37, 'Dr. Tahera Nazrin ', 'joy vaiu', '2021-10-11');

-- --------------------------------------------------------

--
-- Table structure for table `doctortbl`
--

CREATE TABLE `doctortbl` (
  `dtid` int(100) NOT NULL,
  `dtname` varchar(50) NOT NULL,
  `dtdegree` varchar(50) NOT NULL,
  `dtdept` varchar(50) NOT NULL,
  `dtchamber` varchar(50) NOT NULL,
  `dtvisitingtime` varchar(50) NOT NULL,
  `dtvisitingdays` varchar(50) NOT NULL,
  `dtphone` varchar(50) NOT NULL,
  `dtuser_name` varchar(50) NOT NULL,
  `dtemail_id` varchar(50) NOT NULL,
  `dtpass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctortbl`
--

INSERT INTO `doctortbl` (`dtid`, `dtname`, `dtdegree`, `dtdept`, `dtchamber`, `dtvisitingtime`, `dtvisitingdays`, `dtphone`, `dtuser_name`, `dtemail_id`, `dtpass`) VALUES
(9, 'MD.JAWADUL HASAN', 'MBBS,FCPS', 'CARDIOLOGY & BRAIN', ' DMC', ' 11AM-2PM', 'MON-WED', ' 01707615220', 'jawad12', 'jhjawad111@gmail.com', '12'),
(11, 'Prof.Dr.AQM Reza ', 'MBBS MD (Cardiology)', 'Cardiology', 'level-5 (OPD)', '09:00 AM - 5:00 PM ', 'SAT-THU', '09666710678', 'REZA12', 'reja@gmail.com', '123'),
(13, 'Dr. Tahera Nazrin ', 'MBBS(SSMC) DCH (BICH), FCPS (Paed)', 'Cardiology', 'level-5 (OPD)', '09:00 AM - 5:00 PM ', 'SAT-THU', '55037242', 'tahera12', 'tahera@gmail.com', '123'),
(16, 'Prof. Dr. Tamzeed Ahmed ', 'MBBS MRPC (UK)', 'Cardiology', 'level-5 (OPD)', '09:00 AM - 5:00 PM ', 'SAT-THU', '06666710678', 'ahmed12', 'ahmed@gmail.com', '123'),
(20, 'Dr. Abdu Ali ', 'MBBS ', 'Consultant,  Diabetes ', 'MUKTI ', '5.00PM - 9.00PM', 'SAT-THU', ' +880-2-9896165', 'abdu12', 'abdu@gmail.com', '123'),
(21, 'Dr. Zafar A. Latif ', 'MBBS MD (Cardiology)', 'Cardiology', 'Ibrahim General Hospital & DCEC - Dhanmondi ', '10.00AM - 1.00PM', 'SAT-THU', '+880-2- 9146357', 'latif12', 'latif@gmail.com', '123'),
(25, 'Dr. Indrajit Prasad ', 'MBBS, FCPS, MD, MACE ( USA ) ', 'Diabetes & Endocrine ', 'Labaid Specialized Hospital ', '4.00PM - 10.00PM', 'SAT-THU', '+ 880-2-8610', 'Indrajit12', 'Indrajit@gmail.com', '123'),
(26, 'Dr. Afsana Begum', 'MBBS, FCPS ', 'Medicine ', 'United Hospital Limited', '4 PM-8 PM ', 'SAT-THU', ' +880-2-8836000', 'Afsana12', 'Afsana @gmail.com', '123'),
(27, 'Dr. Anup Kumar Saha', ' MBBS, FCPS   ', '  Medicine ', 'Health & Hope Hospital Ltd.', '5 PM-9 PM  ', 'SAT-THU', '+880-2-8318135', ' Anup12', ' Anup@gmail.com', '123'),
(28, 'Abir Hossain', 'MBBS, DTCD, MD(Chest)', 'Medicine Specialist ', 'Medinova Medical Services ', '5 PM-10 PM  ', 'SAT-THU', ' +880-2-8333811-3', 'Abir12', 'Abir@gmail.com', '123'),
(30, 'Dr. Md. Anisur Rahman ', 'MBBS,FCPS ', 'Allergy', 'Popular Diagnostic Centre Ltd ', '5 PM-9 PM ', 'SAT-THU', ' 09613787801', 'Anisur12', 'Anisur@gmail.com', '123'),
(31, 'Dr. M A Masuda ', 'FCPS, MD ( Gastro ) ', 'Gastroenterology  ', 'Liver Foundation of Bangladesh ', '6 PM-10 PM ', 'SAT-THU', ' +880-2-9146537', 'Masuda12', 'Masuda@gmail.com', '123'),
(32, 'Dr. Md. Anisur Rahman ', 'MBBS,FCPS ', 'Orthopedic', 'Popular Diagnostic Centre Ltd ', '5 PM-9 PM ', 'SAT-THU', ' 09613787801', 'Anisur12', 'Anisur@gmail.com', '123'),
(33, 'Dr. Abu Reza Mohammad ', 'Internal Medicine', 'Orthopedic', '', '09:00 AM - 5:00 PM ', 'SAT-THU', ' +880-2-8159457', 'REZA123', 'Reza2@gmail.com', '123'),
(34, 'Dr. Anowar Kabir ', 'MBBS, MRCP, FRCP, FCGE ', 'Senior Consultant ', 'Apollo Hospitals Dhaka', '4 PM-8 PM ', 'SAT-THU', ' +880-2-84016618', 'Anowar12', 'Anowar@gmail.com', '123'),
(35, 'Dr. A.S.M.A  Raihan ', 'MBBS, MD (Gastro),  ', '  Gastroenterology  ', 'Popular Diagnostic Centre Ltd.', '3:00 PM - 8:00 PM  ', 'SAT-THU', '9613787801', 'Raihan12', 'Raihan@gmail.com', '123'),
(36, 'Dr. Md. Abdur Rahim Miah ', 'MBBS, MD', ' Gastroenterology) ', ' Japan Bangladesh Friendship Hospital', '5.30PM - 9.00PM', 'SAT-THU', ' +880-2-9672277', 'Miah12', 'Miah@gmail.com', '123'),
(37, 'Dr. Iqbal Murshed Kabir', 'MBBS, FCPS (Medicine) MD', 'Gastroenterology and Hepatology ', 'Apollo Hospitals Dhaka)', '09:00 AM - 5:00 PM ', 'SAT-THU', ' +880-2-8401661', 'Kabir12', 'Kabir@gmail.com', '123'),
(38, '(Dr.) Md. Fakhrul  Islam ', 'MBBS, MD (Cardiology)  ', 'Heart Failure Specialist ', ' LABAID CARDIAC HOSPITAL', '11 AM-1 PM ', 'SAT-THU', ' 8610793-8', 'Fakhrul12', 'Fakhrul@gmail.com', '123'),
(39, '(Dr.) Mohammad Safiuddin ', 'MB BS(Dhaka), MD(Cardiology)', 'Cardoiogy', 'Popular Medical College Hospital Consultation Cent', '5.00PM - 9.00PM', 'SAT-THU', '06666710678', 'Safiuddin12', 'Safiuddin @gmail.com', '123'),
(40, 'Dr. Abdullah-Al-Safia ', 'MBBS, D. Card, MD(Card), FACC, FSGC', 'Cardiology /Heart Specialist ', 'Popular Diagnostic Centre Ltd.', '11.00PM - 1.00PM', 'SAT-THU', '+8809 606 111 2228', 'Safia12', 'Safia @gmail.com', '123'),
(41, 'Dr. AKM Mosharraf Hossain ', 'MBBS, FCPS', 'Dermatologists ', 'LabAid Specialized Hospital', '2 PM-7 PM  ', 'SAT-THU', ' +880-2-9676356', 'Mosharraf12', 'Mosharraf@gmail.com', '123'),
(42, 'Dr. Syed Rezaul Huq', 'MBBS, FRCP,  ', 'Dermatologists', 'Aysha Memorial Specialised Hospital', '4 PM-8 PM ', 'SAT-THU', ' +880-2-9122689', ' Rezaul12', ' Rezaul@gmail.com', '123'),
(44, 'Dr. Md. Atiqur Rahman', 'MBBS (Dhaka), DTCD ', '  Infectious disease doctors  ', 'Lab-Aid Gulshand.', '5:00 PM - 10:00 PM  ', 'WED-MON', '+880-2-8835981-4', ' Atiqur12', ' Atiqur@gmail.com', '123'),
(45, 'Dr. A.T.M. Asaduzzaman', 'MBBS, MD ', 'Infectious disease doctors   ', 'Japan Bangladesh Friendship Hospital ', '7:30 PM-9:30 PM ', 'SUN-TUE', ' 9672277', ' Asaduzzaman12', ' Asaduzzaman@gmail.com', '123'),
(46, 'Dr. Abida Sultana ', 'MBBS (Dhaka), DDV  ', ' Infectious disease doctors', 'Bangabandhu Sheikh Mujib Medical University ', '6 PM-9 PM ', 'SAT-THU', '8951928', 'Abida12', 'Abida@gmail.com', '123'),
(47, 'Dr. Md. Anwarul Karim ', 'MBBS, DIH, DEM', 'Ophthalmologists ', 'Central Hospital.', '07:00 AM - 10:00 PM ', 'THU-SUN', ' 01819217631', 'Anwarul12', 'Anwarul@gmail.com', '123'),
(48, 'Dr. Md. Abdul Aziz ', 'MBBS, MRCP ', 'Ophthalmologists', ' Hematology Center', '9AM - 5PM ', 'SAT-THU', ' 01731 236255', 'Aziz12', ' Aziz@gmail.com', '123'),
(49, 'Prof. Dr. A H M Nazmul Tariqul Islam ', 'MBBS, FCPS ', ' Ophthalmologists', 'Green Life Hospital', '011:00 AM - 5:00 PM ', 'SUN-THU', '+880 9613 787801', 'Nazmul12', 'Nazmul @gmail.com', '123'),
(50, 'Dr. Md. Zahir Uddin', 'MBBS, FCPS ', 'Obstetrician/gynecologist  ', 'Popular Diagnostic Centre Ltd ', '10AM - 2PM ', 'SAT-THU', '+880 9613 787801', 'Zahir12', 'Zahir@gmail.com', '123'),
(51, 'Dr. Md. Faizul  Islam Chowdhury', 'MBBS, FCPS  ', 'Obstetrician/gynecologist ', 'Popular Diagnostic Centre Ltd ', '4:00 PM - 6:30 PM  ', 'SAT-THU', ' +880 9613 787801', 'Faizul12', 'Faizul@gmail.com', '123'),
(55, 'Dr. Kamal Sayed Ahmed  Chowdhury', 'MBBS FCPS  ', ' Obstetrician/gynecologist', 'Universal Medical College & Hospital Ltd. ', '5.00PM - 9.00PM', 'SAT-THU', ' 09 606 111 222', 'Sayed12', 'Sayed@gmail.com', '123'),
(56, 'Dr. Saroj Kant Sinha ', ' MBBS, MD ', '  Endocrinologists', 'Apollo Hospitals Dhaka', '05:30 PM - 09:00 PM ', 'SAT-THU', ' +880 1841276556', 'Saroj12', 'Saroj@gmail.com', '123'),
(57, 'Dr. Mohammad  Zohir Uddin ', 'MBBS, FCPS  ', 'Endocrinologists', 'Ibn Sina Diagnostic & Imaging Center ', '6 PM -9 PM ', 'SAT-THU', ' 9128835-7', 'Zohir12', 'Zohir@gmail.com', '123'),
(58, 'Dr. Md. Rafiqul Islam', 'MBBS', 'Endocrinologists', 'Labaid Hospital', '09:00 AM - 5:00 PM ', 'SAT-THU', '9012102', 'Rafiqul12', 'Rafiqul@gmail.com', '123'),
(59, 'Ishan Islam', 'MBBS', 'Medicine', ' DMC', ' 7PM-10PM', 'SUN-TUE', ' 01707615220', 'ishan', 'ishan@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `donortbl`
--

CREATE TABLE `donortbl` (
  `did` int(255) NOT NULL,
  `dnrname` varchar(50) NOT NULL,
  `dnrphone` varchar(50) NOT NULL,
  `dnrbrgp` varchar(50) NOT NULL,
  `dnrcity` varchar(50) NOT NULL,
  `dnrarea` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donortbl`
--

INSERT INTO `donortbl` (`did`, `dnrname`, `dnrphone`, `dnrbrgp`, `dnrcity`, `dnrarea`) VALUES
(5, 'MD.JAWADUL HASAN', '01707615220', 'AB+', 'Dhaka', 'Banasree'),
(8, 'Jawad', '01707615220', 'A+', 'Dhaka', 'Shibchar'),
(9, 'joy matubber', '0169019101', 'A+', 'dhaka', 'lalbagh'),
(10, 'rana islam', '0179019101', 'Ab+', 'Dhaka', 'Merul'),
(12, 'aritra das', '0155019105', 'A-', 'Khulna', 'hatirbagan'),
(13, 'Akbar islam', '0169019101', 'A+', 'Khulna', 'jamalgong'),
(14, 'kasem Hok ', '0189019101', 'A-', 'Dhaka', 'Nobabgong'),
(15, 'Jahid hasn', '0180569101', 'O-', 'Dhaka', 'Romna'),
(16, 'Ishan islam', '0189019101', 'A-', 'Faridpur', 'kaligong'),
(17, 'Babar Azam', '0167019101', 'O+', 'Dhaka', 'Dohar'),
(18, 'Abu Hok ', '0169019708', 'AB+', 'Dhaka', 'Nowabpur'),
(19, 'Jihad hasn', '0150569504', 'O-', 'Dhaka', 'Baridhara'),
(20, 'Kabir sing', '0189019101', 'A-', 'Faridpur', 'pathuriya'),
(21, 'Asiq dawan', '0169019101', 'A+', 'Jamalpur', 'Minabazar'),
(22, 'Rabbi Ahamed', '0158019101', 'O+', 'Dhaka', 'Dhanmondi-2'),
(24, 'Esmile islam', '0149019656', 'A-', 'Dhaka', 'kaligong'),
(25, 'Moktar islam', '0133919101', 'AB+', 'Khulna', 'kayettulli'),
(26, 'kasem siddik ', '0169779101', 'AB-', 'Dhaka', 'mirpur'),
(27, 'jihid hasn', '0183563101', 'O-', 'Dhaka', 'Romna'),
(28, 'hridoy mridha', '0149031911', 'AB-', 'Faridpur', 'kalkini'),
(29, 'samim osman', '0159019101', 'A+', ' Nayarongong', 'muktipara'),
(30, ' Sajahan khan ', '0167019131', 'A-', 'Madaripur', 'Sadar'),
(33, 'Aritra', '01707615220', 'AB+', 'Dhaka', 'Banasree');

-- --------------------------------------------------------

--
-- Table structure for table `patienttbl`
--

CREATE TABLE `patienttbl` (
  `pid` int(255) NOT NULL,
  `ptname` varchar(50) NOT NULL,
  `ptphone` varchar(50) NOT NULL,
  `ptgender` varchar(50) NOT NULL,
  `ptage` int(10) NOT NULL,
  `ptbgrp` varchar(10) NOT NULL,
  `ptusername` varchar(100) NOT NULL,
  `ptpass` varchar(100) NOT NULL,
  `ptuseremail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patienttbl`
--

INSERT INTO `patienttbl` (`pid`, `ptname`, `ptphone`, `ptgender`, `ptage`, `ptbgrp`, `ptusername`, `ptpass`, `ptuseremail`) VALUES
(36, 'MD.JAWADUL HASAN', '01707615220', 'Male', 21, 'B+', 'jh', '12', 'ishan@gmail.com'),
(37, 'joy vaiu', '0170', 'Male', 21, 'AB+', 'joy', '123', 'jq@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `prescriptiontbl`
--

CREATE TABLE `prescriptiontbl` (
  `prsid` int(11) NOT NULL,
  `did` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `prescription` varchar(100) NOT NULL,
  `Date` date NOT NULL,
  `Dtname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prescriptiontbl`
--

INSERT INTO `prescriptiontbl` (`prsid`, `did`, `pid`, `prescription`, `Date`, `Dtname`) VALUES
(1, 13, 36, 'FExo', '2021-10-27', 'Dr. Tahera Nazrin '),
(2, 13, 36, 'Fexo Fast -120\r\nMonas 10\r\nNapa\r\nVaccine Verocell\r\n', '2021-10-30', 'Dr. Tahera Nazrin ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointmenttbl`
--
ALTER TABLE `appointmenttbl`
  ADD PRIMARY KEY (`aptid`);

--
-- Indexes for table `doctortbl`
--
ALTER TABLE `doctortbl`
  ADD PRIMARY KEY (`dtid`);

--
-- Indexes for table `donortbl`
--
ALTER TABLE `donortbl`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `patienttbl`
--
ALTER TABLE `patienttbl`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `prescriptiontbl`
--
ALTER TABLE `prescriptiontbl`
  ADD PRIMARY KEY (`prsid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointmenttbl`
--
ALTER TABLE `appointmenttbl`
  MODIFY `aptid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `doctortbl`
--
ALTER TABLE `doctortbl`
  MODIFY `dtid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `donortbl`
--
ALTER TABLE `donortbl`
  MODIFY `did` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `patienttbl`
--
ALTER TABLE `patienttbl`
  MODIFY `pid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `prescriptiontbl`
--
ALTER TABLE `prescriptiontbl`
  MODIFY `prsid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
